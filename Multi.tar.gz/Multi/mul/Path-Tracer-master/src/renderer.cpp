#include <vector>
#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include "renderer.h"
#include "../lib/lodepng/lodepng.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <sys/wait.h>


// Clamp double to min/max of 0/1
inline double clamp(double x){ return x<0 ? 0 : x>1 ? 1 : x; }
// Clamp to between 0-255
inline int toInt(double x){ return int(clamp(x)*255+.5); }

Renderer::Renderer(Scene *scene, Camera *camera) {
    m_scene = scene;
    m_camera = camera;
    m_pixel_buffer = new Vec[m_camera->get_width()*m_camera->get_height()];
   //_pixel_buffer1 = new Vec[m_camera->get_width()*m_camera->get_height()];
}

void Renderer::render(int samples) {
    int width = m_camera->get_width();
    int height = m_camera->get_height();
    double samples_recp = 1./samples;
     key_t key;
    int shmid;
    //m_pixel_buffer = new Vec[m_camera->get_width()*m_camera->get_height()];
    //void *m_pixel_buffer;
    //v//oid *teste;
    key =123;
    int mem_size = sizeof(struct Vec);
    shmid = shmget(key,(m_camera->get_width()*m_camera->get_height())*mem_size, 0644|IPC_CREAT);
    m_pixel_buffer= (Vec *) shmat(shmid, 0, 0);
    //shmid1= shmget(key,)
    //ray = (Vec *) shmat(shmid,0,0);

    //dynamic_cast<Vec*>(teste);
    //m_pixel_buffer = teste;
    //pid_t pid;
    //pid = fork();
    //m_pixel_buffer = new Vec[m_camera->get_width()*m_camera->get_height()];
    /*if(pid==0)  {
          m_pixel_buffer= (Vec *) shmat(shmid, 0, 0);
    }
    if(pid>0){
          m_pixel_buffer= (Vec *) shmat(shmid, 0, 0);
    }*/
    // Main Loop
    int i=0;
    int j=0;
    sem_t sem;
    //printf("%d", width);
    //printf("%d", height);
    int n_workers = 8;
    int blockzise = height/n_workers;
    //printf("%d \n", blockzise);;
    

    pid_t pid;
    for(i=0; i<n_workers; i++){
    	//pid_t pid;
    	pid = fork();
    	printf("%d",i);
    	//for(j=i*blockzise; j<(i+1)*blockzise; j++){
    	 if(pid==0){
    	 for(j=i*blockzise; j<=(i+1)*blockzise; j++){

    	//printf("%d",j);
    	printf("alo");
        //pid = fork();
        //sem_wait(&sem);
      
        unsigned short Xi[3]={0,0,j*j*j};               // Stores seed for erand48
        //printf("haddady esteve aqui");
        fprintf(stderr, "\rRendering (%i samples): %.2f%% ",      // Prints
                samples, (double)j/height*100);                   // progress
           //sem_wait(&sem);
        for (int x=0; x<width; x++){
            Vec col = Vec();

            for (int a=0; a<samples; a++){
                Ray ray = m_camera->get_ray(x, j, a>0, Xi);
                col = col + m_scene->trace_ray(ray,0,Xi);
                //printf("aqui");
            }
             //printf("%d",y);  
            //sem_wait(&sem);
            m_pixel_buffer[(j)*width + x] = col * samples_recp;
            
               /// i=0;
                //printf("fodase\n");
                //printf("%lf aqui \n", m_pixel_buffer[(y)*width + x].x);
            
           //printf("%lf", m_pixel_buffer[0].x);
            //printf("caguei");
            //sem_post(&sem);
              //while(wait(NULL) > 0);
        
        }
       //exit(1);
       //pid = fork(); 
        //while(wait(NULL) > 0);
        //i=0;
        //exit(0);
         //pid = fork();
         //printf("fodase"); 
        /* if(pid ==0){
             printf("me chupa");
            exit(1);
         }*/ 
            //while(wait(NULL) > 0);
            //exit(1);
            //shmdt(image);
    //shmctl(shmid, IPC_RMID, NULL);
            //sem_wait(&sem);
            //pid = fork();
            //renderer.save_image("render2.png");
    }


    	exit(0);
	
	}//aqui	//exit(0);
 		//exit(0);

    }
    	//exit(0);
	
    	if(pid>0){

    		while(wait(NULL)>0);

    	}
 }

//}

void Renderer::save_image(const char *file_path) {
    int width = m_camera->get_width();
    int height = m_camera->get_height();

    std::vector<unsigned char> pixel_buffer;

    int pixel_count = width*height;

    for (int i=0; i<pixel_count; i++) {
        pixel_buffer.push_back(toInt(m_pixel_buffer[i].x));
        pixel_buffer.push_back(toInt(m_pixel_buffer[i].y));
        pixel_buffer.push_back(toInt(m_pixel_buffer[i].z));
        pixel_buffer.push_back(255);
    }

    //Encode the image
    unsigned error = lodepng::encode(file_path, pixel_buffer, width, height);
    //if there's an error, display it
    if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;
   
    pixel_buffer.clear();
}
