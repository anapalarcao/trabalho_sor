#pragma once

extern "C" double erand48(unsigned short xseed[3]);